import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import './BookDetail.css'; 


const BookDetail = () => {
    const { id } = useParams();
    const [book, setBook] = useState(null);

    const booksData = [
        {
            id: 1,
            title: "Mayyazhi puzhayude theerangalil",
            description: "Explanation about kerala nature.",
            publicationYear: 1997,
            author: { id: 1, name: "M mukundan" },
            category: { id: 1, name: "story" }
        },
        {
            id: 2,
            title: "A Game of Thrones",
            description: "A tale of power and betrayal.",
            publicationYear: 1996,
            author: { id: 2, name: "George R.R. Martin" },
            category: { id: 2, name: "Fantasy" }
        }
        
    ];

    useEffect(() => {
        const foundBook = booksData.find(book => book.id === parseInt(id));
        setBook(foundBook);
    }, [id]);

    const deleteBook = () => {
        alert(`Book '${book.title}' has been deleted!`);
        setBook(null);
    };

    if (!book) return <div>Loading...</div>;

    return (
        <div className='book'>
            <h2>{book.title}</h2>
            <p>{book.description}</p>
            <p>Publication Year: {book.publicationYear}</p>
            <p>Author: {book.author.name}</p>
            <p>Category: {book.category.name}</p>
            <button onClick={deleteBook}>Delete Book</button>
        </div>
    );
};

export default BookDetail;