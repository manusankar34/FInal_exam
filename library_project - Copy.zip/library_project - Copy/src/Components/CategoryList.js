import React, { useState } from 'react';

const CategoryList = () => {
    const [categories, setCategories] = useState([
        { categoryId: 1, name: 'Fiction' },
        { categoryId: 2, name: 'Non-Fiction' },
        { categoryId: 3, name: 'Science Fiction' },
        { categoryId: 4, name: 'Fantasy' }
    ]);
    const [newCategory, setNewCategory] = useState('');

    const addCategory = () => {
        if (newCategory.trim() === '') {
            alert('Category name cannot be empty!');
            return;
        }

        const newCategoryObject = {
            categoryId: categories.length + 1, 
            name: newCategory
        };
        
        setCategories([...categories, newCategoryObject]);
        setNewCategory(''); 
    };

    return (
        <div>
            <h2>Categories</h2>
            <ul>
                {categories.map(category => (
                    <li key={category.categoryId}>{category.name}</li>
                ))}
            </ul>
            <input 
                type="text" 
                value={newCategory} 
                onChange={e => setNewCategory(e.target.value)} 
                placeholder="New Category Name" 
            />
            <button onClick={addCategory}>Add Category</button>
        </div>
    );
};

export default CategoryList;