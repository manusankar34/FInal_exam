import React from 'react';
import { Link } from 'react-router-dom';


const Navbar = () => {
    return (
        <div className="navbar">
            <h1>Library management system</h1>
        <div className="sameline">

            <ul class>
                <li><Link to="/">Home</Link></li>
                <li><Link to="/authors">Authors</Link></li>
                <li><Link to="/categories">Categories</Link></li>
                <li><Link to="/books">Books</Link></li>
            </ul>
        </div>

        <div className='imgk'>
            
        </div>
        </div>
    );
};

export default Navbar;


