import React, { useState } from 'react';
import './AuthorList.css'; 

const AuthorList = () => {
    const [authors, setAuthors] = useState([
        { authorId: 1, name: 'Sugatha kumari' },
        { authorId: 2, name: 'Onv kurupp' },
        { authorId: 3, name: 'kunjunni master' },
    ]);

    const [newAuthor, setNewAuthor] = useState('');

    const addAuthor = () => {
        if(newAuthor.trim() === '') return; 
        const newAuthorObj = {
            authorId: authors.length + 1, 
            name: newAuthor
        };
        setAuthors([...authors, newAuthorObj]);
        setNewAuthor(''); 
    };

    return (
        <div className="author-list">
            <h2>Authors</h2>
            <ul>
                {authors.map(author => (
                    <li key={author.authorId}>{author.name}</li>
                ))}
            </ul>
            <input 
                type="text" 
                value={newAuthor} 
                onChange={e => setNewAuthor(e.target.value)} 
                placeholder="New Author Name" 
            />
            <button onClick={addAuthor}>Add Author</button>
        </div>
    );
};

export default AuthorList;