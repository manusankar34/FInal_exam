import React, { useState } from 'react';
import './BookList.css'; 

const BookList = () => {
    const [books, setBooks] = useState([
        {
            id: 1,
            title: "nelambari",
            description: "A young boy discovers he is a wizard.",
            publicationYear: 1997,
            author: { id: 1, name: "sugatha kumari" },
            category: { id: 1, name: "poem" }
        },
        {
            id: 2,
            title: "A Game of Thrones",
            description: "A tale of power and betrayal.",
            publicationYear: 1996,
            author: { id: 2, name: "George R.R. Martin" },
            category: { id: 2, name: "Fantasy" }
        }
       
    ]);

    const [newBook, setNewBook] = useState({
        title: '',
        description: '',
        publicationYear: '',
        authorId: '',
        categoryId: ''
    });

    const addBook = () => {
        if (newBook.title.trim() === '') return; 
        const nextId = books.length + 1; 
        const newBookObj = {
            id: nextId,
            ...newBook,
            author: { id: newBook.authorId, name: `Author ${newBook.authorId}` }, 
            category: { id: newBook.categoryId, name: `Category ${newBook.categoryId}` },
        };
        setBooks([...books, newBookObj]);
        setNewBook({ title: '', description: '', publicationYear: '', authorId: '', categoryId: '' }); 
    };

    return (
        <div className="book-list">
            <h2>Books</h2>
            <ul>
                {books.map(book => (
                    <li key={book.id}>
                        {book.title} - {book.description} ({book.publicationYear}) by {book.author.name} in {book.category.name}
                    </li>
                ))}
            </ul>
            <input
                type="text"
                value={newBook.title}
                onChange={e => setNewBook({ ...newBook, title: e.target.value })}
                placeholder="Title"
            />
            <input
                type="text"
                value={newBook.description}
                onChange={e => setNewBook({ ...newBook, description: e.target.value })}
                placeholder="Description"
            />
            <input
                type="number"
                value={newBook.publicationYear}
                onChange={e => setNewBook({ ...newBook, publicationYear: e.target.value })}
                placeholder="Publication Year"
            />
            <input
                type="number"
                value={newBook.authorId}
                onChange={e => setNewBook({ ...newBook, authorId: e.target.value })}
                placeholder="Author ID"
            />
            <input
                type="number"
                value={newBook.categoryId}
                onChange={e => setNewBook({ ...newBook, categoryId: e.target.value })}
                placeholder="Category ID"
            />
            <button onClick={addBook}>Add Book</button>
        </div>
    );
};

export default BookList;