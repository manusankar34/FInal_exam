import './App.css'; // Make sure the path is correct
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './Components/Navbar';
import AuthorList from './Components/AuthorList';
import CategoryList from './Components/CategoryList';
import BookList from './Components/BookList';
import BookDetail from './Components/BookDetail';

const App = () => {
    return (
        <Router>
            <div>
                <Navbar />
                <Routes>
          
                    <Route path="/authors" element={<AuthorList/>} />
                    <Route path="/categories" element={<CategoryList/>} />
                    <Route path="/books" element={<BookList/>} />
                    <Route path="/books/:id" element={<BookDetail/>} />
                    </Routes>

           
            </div>
        </Router>
    );
};

export default App;
