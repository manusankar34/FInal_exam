﻿namespace Library_managment.Models.Request
{
    public class Catgryrequest
    {
        public string Name { get; set; }

        public string Description { get; set; }
    }
}
