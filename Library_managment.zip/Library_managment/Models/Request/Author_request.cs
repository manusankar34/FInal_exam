﻿namespace Library_managment.Models.Request
{
    public class Author_request
    {
        public string Name { get; set; }
        public string Bio { get; set; }
    }
}
