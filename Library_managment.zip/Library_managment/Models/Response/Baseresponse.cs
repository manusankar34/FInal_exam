﻿namespace Library_managment.Models.Response
{
    public class Baseresponse
    {

        public int SuccessCode { get; set; }
        public string Message { get; set; }
    }
}
