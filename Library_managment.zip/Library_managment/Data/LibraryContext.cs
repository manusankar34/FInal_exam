﻿using Library_managment.Models;
using Library_managment.Models.Entities;
using Microsoft.EntityFrameworkCore;


namespace Library_managment.Data
{
    public class LibraryContext : DbContext
    {
        public LibraryContext(DbContextOptions<LibraryContext> options) : base(options)
        {
        }

        public DbSet<Book> Books { get; set; }
        public DbSet<Author> Authors { get; set; }
        public DbSet<Cateogry> Categories { get; set; }



    }
}
