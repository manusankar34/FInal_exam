﻿using Library_managment.Data;
using Library_managment.Models.Request;
using Library_managment.Models.Response;
using Library_managment.Models.Entities;
using Microsoft.AspNetCore.Mvc;

namespace Library_managment.Controllers
{

    [Route("Category/api")]
    public class CategoryController : Controller
    {

        private LibraryContext dbContext;

        public CategoryController(LibraryContext dBContext_)
        {
            this.dbContext = dBContext_;
        }


        [HttpPost("Category")]
        public IActionResult CategoryEntry([FromBody] Catgryrequest request)
        {

            var _categry = new Cateogry()
            {
                Name = request.Name,
                Description = request.Description,
            };
            dbContext.Categories.Add(_categry);
            dbContext.SaveChanges();

            Baseresponse response = new Baseresponse();
            response.SuccessCode = 1;
            response.Message = "Success";
            return Ok(response);
        }



        [HttpGet("_categorylist")]
        public IActionResult GetBook()
        {
            var resp = dbContext.Categories.ToList();

            Baseresponse response = new Baseresponse();
            response.SuccessCode = 1;
            response.Message = "Success";

            return Ok(resp);
        }


        [HttpGet("Get_categoryItem")]
        public IActionResult FilterBook([FromQuery] BookFilterRequest request)
        {
            var resp = dbContext.Categories.Find(request.id);

            Baseresponse response = new Baseresponse();
            response.SuccessCode = 1;
            response.Message = "Success";

            return Ok(resp);
        }
    }
}
