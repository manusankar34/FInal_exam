﻿using Library_managment.Data;
using Library_managment.Models.Response;
using Library_managment.Models.Entities;
using Microsoft.AspNetCore.Mvc;
using Library_managment.Models.Entities;

namespace Library_managment.Controllers
{

    [Route("Author/api")]
    public class AuthorController : Controller
    {

        private LibraryContext dbContext;

        public AuthorController(LibraryContext dBContext_)
        {
            this.dbContext = dBContext_;
        }


        [HttpPost("AuthorEntry")]
        public IActionResult Author([FromBody] Author request)
        {

            var _authorModel = new Author()
            {
                Name = request.Name,
                Bio = request.Bio
            };

            dbContext.Authors.Add(_authorModel);
            dbContext.SaveChanges();


           


            return Ok(_authorModel);
        }


        [HttpGet("Authorlist")]
        public IActionResult GetAuthor()
        {


            var resp = dbContext.Authors.ToList();

           
            return Ok(resp);
        }


        [HttpGet("Get_authorItem")]
        public IActionResult FilterBook([FromQuery] Author request)
        {


            var resp = dbContext.Authors.Find(request.Name);

         
         

            return Ok(resp);
        }
    }
}
