﻿using Library_managment.Data;
using Library_managment.Models;
using Library_managment.Models.Entities;
using Library_managment.Models.Request;
using Library_managment.Models.Response;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;



namespace Library_managment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Route("Books/api")]
    public class BookController : Controller
    {

        private LibraryContext dbContext;

        public BookController(LibraryContext dBContext_)
        {
            this.dbContext = dBContext_;
        }

        [HttpPost("BookEntry")]
        public IActionResult BookEntry([FromBody] bkrequest request)
        {
            var _bookres = new Book()
            {
                Title = request.Title,
                Description = request.Description,
                PublicationYear = request.PublicationYear,
                AuthorId = request.AuthorId,
                CategoryId = request.CategoryId

            };
            dbContext.Books.Add(_bookres);
            dbContext.SaveChanges();

            Baseresponse response = new Baseresponse();
            response.SuccessCode = 1;
            response.Message = "Success";

            return Ok(response);
        }


        [HttpGet("Booklist")]
        public IActionResult GetBook()
        {
            var resp = dbContext.Books.ToList();

            Baseresponse response = new Baseresponse();
            response.SuccessCode = 1;
            response.Message = "Success";

            return Ok(resp);
        }


        [HttpGet("GetBookItem")]
        public IActionResult FilterBook([FromQuery] BookFilterRequest request)
        {
            var resp = dbContext.Books.Find(request.id);

            Baseresponse response = new Baseresponse();
            response.SuccessCode = 1;
            response.Message = "Success";

            return Ok(resp);
        }
    }
}
